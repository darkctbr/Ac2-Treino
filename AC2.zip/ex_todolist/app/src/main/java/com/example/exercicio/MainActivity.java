package com.example.exercicio;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText  inputExerc;
    Spinner spinnerGeneroCadastro, spinnerFiltroGeneroLista, spinnerOrdenacao;
    CheckBox checkVistoCinema, checkFiltroCinema;
    Button botaoIniciartreino;
    ListView listaExercicioView;

    BancoHelper bancoDados;
    ArrayAdapter<String> exercAdapter;
    ArrayList<String>exercTexto;
    ArrayList<Integer> exercIds;

    int idFilmeEditando = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        inputExerc = findViewById(R.id.edexerc);

        spinnerGeneroCadastro = findViewById(R.id.spinnerGenero);
        botaoIniciartreino = findViewById(R.id.btnSalvar);
        listaExercicioView = findViewById(R.id.listaExercicioView);
        spinnerFiltroGeneroLista = findViewById(R.id.spinnerFiltroGenero);
        spinnerOrdenacao = findViewById(R.id.spinnerOrdenar);

        bancoDados = new BancoHelper(this);
        exercTexto = new ArrayList<>();
        exercIds = new ArrayList<>();
        exercAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, exercTexto);
        listaExercicioView.setAdapter(exercAdapter);

        configurarSpinnersGeneroOrdenacao();

        atualizarListaFilmes();

        botaoIniciartreino.setOnClickListener(v -> {
            String exerc = inputExerc.getText().toString();

            if ( exerc.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                return;
            }

            int ano = Integer.parseInt(exerc);
            String genero = spinnerGeneroCadastro.getSelectedItem().toString();
            int viuCinema = checkVistoCinema.isChecked() ? 1 : 0;

            if (idFilmeEditando == -1) {
                bancoDados.inserirFilme(exerc,genero,viuCinema);
                Toast.makeText(this, "Filme cadastrado!", Toast.LENGTH_SHORT).show();
            } else {
                bancoDados.atualizarFilme(idFilmeEditando, exerc, genero, viuCinema);
                Toast.makeText(this, "Filme atualizado!", Toast.LENGTH_SHORT).show();
                idFilmeEditando = -1;
            }

            limparCamposFormulario();
            atualizarListaFilmes();
        });

        listaExercicioView.setOnItemClickListener((parent, view, position, id) -> {
            int filmeId = exercIds.get(position);
            Cursor cursor = bancoDados.getReadableDatabase().rawQuery("SELECT * FROM filmes WHERE id = ?", new String[]{String.valueOf(filmeId)});
            if (cursor.moveToFirst()) {
                idFilmeEditando = filmeId;
                inputExerc.setText(String.valueOf(cursor.getInt(cursor.getColumnIndexOrThrow("Exercicio"))));
                String genero = cursor.getString(cursor.getColumnIndexOrThrow("genero"));
                spinnerGeneroCadastro.setSelection(((ArrayAdapter<String>) spinnerGeneroCadastro.getAdapter()).getPosition(genero));
                checkVistoCinema.setChecked(cursor.getInt(cursor.getColumnIndexOrThrow("viu_cinema")) == 1);
            }
            cursor.close();
        });

        listaExercicioView.setOnItemLongClickListener((parent, view, position, id) -> {
            int filmeId = exercIds.get(position);
            bancoDados.excluirFilme(filmeId);
            Toast.makeText(this, "Filme excluído!", Toast.LENGTH_SHORT).show();
            atualizarListaFilmes();
            return true;
        });

        AdapterView.OnItemSelectedListener listenerFiltros = new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                atualizarListaFilmes();
            }

            @Override public void onNothingSelected(AdapterView<?> parent) { }
        };

        spinnerFiltroGeneroLista.setOnItemSelectedListener(listenerFiltros);
        spinnerOrdenacao.setOnItemSelectedListener(listenerFiltros);
        checkFiltroCinema.setOnCheckedChangeListener((buttonView, isChecked) -> atualizarListaFilmes());
    }

    private void configurarSpinnersGeneroOrdenacao() {
        String[] generos = {"Todos", "Ação", "Comédia", "Drama", "Terror", "Ficção"};
        ArrayAdapter<String> adaptadorGeneros = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, generos);
        adaptadorGeneros.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGeneroCadastro.setAdapter(adaptadorGeneros);
        spinnerFiltroGeneroLista.setAdapter(adaptadorGeneros);

        String[] opcoesOrdenacao = {"Título", "Ano", "Nota"};
        ArrayAdapter<String> adaptadorOrdenacao = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opcoesOrdenacao);
        adaptadorOrdenacao.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerOrdenacao.setAdapter(adaptadorOrdenacao);
    }

    private void atualizarListaFilmes() {
        exercTexto.clear();
        exercIds.clear();

        String generoSelecionado = spinnerFiltroGeneroLista.getSelectedItem().toString();
        boolean apenasCinema = checkFiltroCinema.isChecked();
        String criterioOrdenacao = spinnerOrdenacao.getSelectedItem().toString();

        Cursor cursor = bancoDados.filtrarCombinado(generoSelecionado, apenasCinema, criterioOrdenacao);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String titulo = cursor.getString(cursor.getColumnIndexOrThrow("titulo"));
                int ano = cursor.getInt(cursor.getColumnIndexOrThrow("ano"));
                int nota = cursor.getInt(cursor.getColumnIndexOrThrow("nota"));
                String genero = cursor.getString(cursor.getColumnIndexOrThrow("genero"));

                String descricao = titulo + " (" + ano + ") - " + genero + " - Nota: " + nota;
                exercTexto.add(descricao);
                exercIds.add(id);
            } while (cursor.moveToNext());
        }
        cursor.close();
      exercAdapter.notifyDataSetChanged();
    }

    private void limparCamposFormulario() {
        inputExerc.setText("");
        checkVistoCinema.setChecked(false);
        spinnerGeneroCadastro.setSelection(0);
    }
}
