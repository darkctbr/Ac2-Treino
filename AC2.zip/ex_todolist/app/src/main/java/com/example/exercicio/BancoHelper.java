package com.example.exercicio;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.*;

import java.util.ArrayList;
import java.util.List;

public class BancoHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "exerc.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "filmes";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TITULO = "titulo";
    private static final String COLUMN_DIRETOR = "diretor";
    private static final String COLUMN_EXERC = "exercicio";
    private static final String COLUMN_VIU_CINEMA = "viu_cinema";

    public BancoHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_TITULO + " TEXT NOT NULL, "
                + COLUMN_DIRETOR + " TEXT NOT NULL, "
                + COLUMN_EXERC + " INTEGER NOT NULL, "
                + COLUMN_VIU_CINEMA + " INTEGER NOT NULL)";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public long inserirFilme(String titulo, String diretor, int ano, int nota, String genero, int viuCinema) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITULO, titulo);
        values.put(COLUMN_DIRETOR, diretor);
        values.put(COLUMN_EXERC, ano);
        values.put(COLUMN_GENERO, genero);
        values.put(COLUMN_VIU_CINEMA, viuCinema);
        return db.insert(TABLE_NAME, null, values);
    }

    public Cursor listarFilmes() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME + " ORDER BY " + COLUMN_TITULO + " ASC", null);
    }

    public int atualizarFilme(int id, String titulo, String diretor, int ano, int nota, String genero, int viuCinema) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITULO, titulo);
        values.put(COLUMN_DIRETOR, diretor);
        values.put(COLUMN_EXERC, ano);
        values.put(COLUMN_GENERO, genero);
        values.put(COLUMN_VIU_CINEMA, viuCinema);
        return db.update(TABLE_NAME, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    public int excluirFilme(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    public Cursor filtrarCombinado(String genero, boolean viuCinema, String ordenacao) {
        SQLiteDatabase db = this.getReadableDatabase();

        StringBuilder query = new StringBuilder("SELECT * FROM " + TABLE_NAME + " WHERE 1=1");
        List<String> argsList = new ArrayList<>();

        if (genero != null && !genero.equalsIgnoreCase("Todos")) {
            query.append(" AND ").append(COLUMN_GENERO).append("=?");
            argsList.add(genero);
        }

        if (viuCinema) {
            query.append(" AND ").append(COLUMN_VIU_CINEMA).append("=1");
        }

        switch (ordenacao) {
            case "Ano":
                query.append(" ORDER BY ").append(COLUMN_EXERC).append(" ASC");
                break;
            case "Título":
            default:
                query.append(" ORDER BY ").append(COLUMN_TITULO).append(" ASC");
                break;
        }

        String[] args = argsList.isEmpty() ? null : argsList.toArray(new String[0]);
        return db.rawQuery(query.toString(), args);
    }
}




